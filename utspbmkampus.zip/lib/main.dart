import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

// Key Global untuk mengontrol Navigasi dan UI tanpa variabel context di parameter fungsi
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext _) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      scaffoldMessengerKey: messengerKey,
      debugShowCheckedModeBanner: false,
      title: 'Aplikasi Data Kampus',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: false, // Menjaga kompatibilitas style dengan linter lama
      ),
      home: const HomeScreen(),
    );
  }
}

// ==========================================
// KELAS DATABASE HELPER (Logika Database)
// ==========================================
class DatabaseHelper {
  static Future<Database> db() async {
    return openDatabase(
      join(await getDatabasesPath(),
          'kampus_mahasiswa.db'), // Nama file DB baru khusus data kampus
      onCreate: (database, version) async {
        await database.execute(
          """CREATE TABLE mahasiswa(
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            nama TEXT,
            prodi TEXT,
            semester TEXT,
            createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
          )""",
        );
      },
      version: 1,
    );
  }

  // CREATE: Menambahkan data mahasiswa baru
  static Future<int> createItem(
      String nama, String prodi, String semester) async {
    final db = await DatabaseHelper.db();
    final data = {'nama': nama, 'prodi': prodi, 'semester': semester};
    return await db.insert('mahasiswa', data,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // READ: Mengambil semua data mahasiswa
  static Future<List<Map<String, dynamic>>> getItems() async {
    final db = await DatabaseHelper.db();
    return db.query('mahasiswa', orderBy: "id DESC");
  }

  // UPDATE: Memperbarui data mahasiswa yang ada
  static Future<int> updateItem(
      int id, String nama, String prodi, String semester) async {
    final db = await DatabaseHelper.db();
    final data = {
      'nama': nama,
      'prodi': prodi,
      'semester': semester,
      'createdAt': DateTime.now().toString()
    };
    return await db.update('mahasiswa', data, where: "id = ?", whereArgs: [id]);
  }

  // DELETE: Menghapus data mahasiswa
  static Future<void> deleteItem(int id) async {
    final db = await DatabaseHelper.db();
    try {
      await db.delete('mahasiswa', where: "id = ?", whereArgs: [id]);
    } catch (err) {
      debugPrint("Gagal menghapus item: $err");
    }
  }
}

// ==========================================
// KELAS INTERFACE (Tampilan UI)
// ==========================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> _mahasiswaList = [];
  bool _isLoading = true;

  // Controller disesuaikan dengan kebutuhan input data kampus
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _prodiController = TextEditingController();
  final TextEditingController _semesterController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _refreshMahasiswa();
  }

  void _refreshMahasiswa() async {
    try {
      final data = await DatabaseHelper.getItems();
      setState(() {
        _mahasiswaList = data;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint("Error saat mengambil data: $e");
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showForm(int? id) async {
    if (id != null) {
      final existingMahasiswa =
          _mahasiswaList.firstWhere((element) => element['id'] == id);
      _namaController.text = existingMahasiswa['nama'] ?? '';
      _prodiController.text = existingMahasiswa['prodi'] ?? '';
      _semesterController.text = existingMahasiswa['semester'] ?? '';
    } else {
      _namaController.text = '';
      _prodiController.text = '';
      _semesterController.text = '';
    }

    final validContext = navigatorKey.currentContext;
    if (validContext == null) return;

    showModalBottomSheet(
      context: validContext,
      elevation: 5,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: EdgeInsets.only(
          top: 15,
          left: 15,
          right: 15,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Center(
                child: Text(
                  id == null ? 'Tambah Data Mahasiswa' : 'Ubah Data Mahasiswa',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _namaController,
                decoration: const InputDecoration(
                  labelText: 'Nama Mahasiswa',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _prodiController,
                decoration: const InputDecoration(
                  labelText: 'Program Studi (Prodi)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _semesterController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Semester',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(45)),
                onPressed: () async {
                  if (_namaController.text.trim().isEmpty ||
                      _prodiController.text.trim().isEmpty ||
                      _semesterController.text.trim().isEmpty) {
                    messengerKey.currentState?.showSnackBar(const SnackBar(
                      content: Text('Semua bidang input wajib diisi!'),
                    ));
                    return;
                  }

                  if (id == null) {
                    await DatabaseHelper.createItem(
                      _namaController.text,
                      _prodiController.text,
                      _semesterController.text,
                    );
                  } else {
                    await DatabaseHelper.updateItem(
                      id,
                      _namaController.text,
                      _prodiController.text,
                      _semesterController.text,
                    );
                  }

                  _namaController.text = '';
                  _prodiController.text = '';
                  _semesterController.text = '';

                  navigatorKey.currentState?.pop();
                  _refreshMahasiswa();
                },
                child: Text(id == null ? 'Tambah Data' : 'Perbarui Data'),
              )
            ],
          ),
        ),
      ),
    );
  }

  void _deleteItem(int id) async {
    await DatabaseHelper.deleteItem(id);
    messengerKey.currentState?.showSnackBar(const SnackBar(
      content: Text('Data mahasiswa berhasil dihapus!'),
    ));
    _refreshMahasiswa();
  }

  @override
  Widget build(BuildContext _) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD Data Mahasiswa Kampus'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _mahasiswaList.isEmpty
              ? const Center(
                  child: Text("Belum ada data mahasiswa, silakan tambah!"))
              : ListView.builder(
                  itemCount: _mahasiswaList.length,
                  itemBuilder: (ctx, index) => Card(
                    color: Colors.indigo[50],
                    margin:
                        const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.indigo,
                        child: Text(
                          _mahasiswaList[index]['semester'] ?? '',
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(
                        _mahasiswaList[index]['nama'] ?? '',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      subtitle: Text(
                          'Prodi: ${_mahasiswaList[index]['prodi'] ?? ''}'),
                      trailing: SizedBox(
                        width: 100,
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () =>
                                  _showForm(_mahasiswaList[index]['id']),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () =>
                                  _deleteItem(_mahasiswaList[index]['id']),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.person_add),
        onPressed: () => _showForm(null),
      ),
    );
  }
}
